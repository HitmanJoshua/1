package com.assignment1.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import com.assignment1.model.Customer;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Controller
public class CustomerController {
	
	@Autowired
	private RestTemplate template;
	
	@Autowired
	private Customer customer;
	
	@Autowired
	public ModelAndView mdlView;
	
	ObjectMapper mapper = new ObjectMapper();
	
	@RequestMapping("/")
	public String init() {
		  
		return "home";
	}
	
	@GetMapping("/addCustomer")
	public ModelAndView initForm() {
		
		mdlView.setViewName("addCustomer");
		mdlView.addObject("command", customer);
		return mdlView;
	}

	private String postUrl = "http://localhost:8080/addStudent";
	@PostMapping("/addCustomerSubmit")
	public String onSubmit(@ModelAttribute("command") Customer customer) {
		Customer std = this.template.postForObject(this.postUrl, customer, Customer.class);
		
		return "success";
	}	
	
	private String url = "http://localhost:8080/viewStudents";	
	
	
	@GetMapping("/viewCustomers")
	public ModelAndView redirect() throws JsonParseException, JsonMappingException, IOException {
		
		String response =this.template.getForObject(url, String.class);
		
		List<Customer> obj = mapper.readValue(response, ArrayList.class);
		
		mdlView.setViewName("customerDetails");
		mdlView.addObject("command", obj);
		return mdlView;
		
	}
	
	@GetMapping("/deleteCustomer")
	public ModelAndView delete() {
		
		mdlView.setViewName("deletePage");
		mdlView.addObject("command", customer);
		return mdlView;
	}
	
	private String deleteUrl = "http://localhost:8080/delete";
	
	@PostMapping("/deleteById")
	public String deleteId(@ModelAttribute("command") Customer customer) {
		
		String std = this.template.getForObject(this.deleteUrl+"/"+customer.getCustomerId(), String.class);
		return "success";
	}
	
	@GetMapping("/updateCustomer")
	public ModelAndView update() {
		
		mdlView.setViewName("addCustomer");
		mdlView.addObject("command", customer);
		return mdlView;
	}
	
	

}
