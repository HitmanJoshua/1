package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.model.Customer;
import com.example.demo.services.CustomerService;

@SpringBootApplication
public class CustomerDetailsServiceApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(CustomerDetailsServiceApplication.class, args);
		
		
		CustomerService service  = ctx.getBean(CustomerService.class);
		
		Customer std1 = new Customer();
		
		std1.setCustomerId(101);
		std1.setCustomerName("Arul");
		std1.setFavouriteDish("Hamburger");
		std1.setReview("Awesome");
		std1.setAddress("Chennai");
		service.save(std1);
	}

}
