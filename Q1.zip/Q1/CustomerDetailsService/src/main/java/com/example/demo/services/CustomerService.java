package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Customer;
import com.example.demo.repo.CustomerRepository;



@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository repo;
	
//	@Autowired
//	private PaymentRepo payRepo;
	
	
	public Customer save(Customer entity) {
		
		return repo.save(entity);
	}
	
	
	public Iterable<Customer> findAll() {
		
		return repo.findAll();
	}
	
	public Customer findById(long id) {
		
		return repo.findById(id).get();
	}
	
	public void deleteById(long id) throws IllegalArgumentException{
		
		repo.deleteById(id);
	}
	
//	public Student get() {
//		
//		return payRepo.findUser();
//	}

}
